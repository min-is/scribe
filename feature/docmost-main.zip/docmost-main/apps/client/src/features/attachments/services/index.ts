export {
  uploadIcon,
  uploadUserAvatar,
  uploadSpaceIcon,
  uploadWorkspaceIcon,
  removeAvatar,
  removeSpaceIcon,
  removeWorkspaceIcon,
} from "./attachment-service.ts";
