import React from "react";
import { MfaSettings } from "@/ee/mfa";

export function AccountMfaSection() {
  return <MfaSettings />;
}
