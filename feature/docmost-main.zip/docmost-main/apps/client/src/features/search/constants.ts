import { createSpotlight } from '@mantine/spotlight';

export const [searchSpotlightStore, searchSpotlight] = createSpotlight();

export const [shareSearchSpotlightStore, shareSearchSpotlight] =
  createSpotlight();

